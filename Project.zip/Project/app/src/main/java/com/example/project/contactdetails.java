package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class contactdetails extends AppCompatActivity {
    private TextView nametv, phonetv, emailtv, addedtv, updatedtv;
    private ImageView imageView;
    private String id;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactdetails);
        Intent intent = getIntent();
        db = new DBHelper(this);
        id = intent.getStringExtra("contactId");
        nametv = findViewById(R.id.nametv);
        phonetv = findViewById(R.id.phonetv);
        emailtv = findViewById(R.id.emailtv);
        addedtv = findViewById(R.id.addedtv);
        updatedtv = findViewById(R.id.updatedtv);
        imageView = findViewById(R.id.profileimg);
        loaddatabyid();
    }

    private void loaddatabyid() {
        String selectquery;
        selectquery = "SELECT * FROM " + DBHelper.TABLE_NAME + " WHERE " + DBHelper.C_ID + " =\"" + id + "\"";
        SQLiteDatabase mydb = db.getReadableDatabase();
        Cursor cursor = mydb.rawQuery(selectquery, null);
        if (cursor.moveToNext()) {
            String nm = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.C_NAME));
            String img = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.C_IMG));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.C_PHONE));
            String em = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.C_EMAIL));
            String at = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.C_ADDED_TIME));
            String ut = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.C_UPDATED_TIME));

            Calendar calendar = Calendar.getInstance(Locale.getDefault());
            try {
                // Convert the timestamp string into a Date object
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                Date dateAdded = sdf.parse(at);
                Date dateUpdated = sdf.parse(ut);

                // Set the calendar time with the milliseconds value
                calendar.setTimeInMillis(dateAdded.getTime());
                String ta = String.format("%s", DateFormat.format("dd/MM/yy hh:mm:aa", calendar));

                calendar.setTimeInMillis(dateUpdated.getTime());
                String tu = String.format("%s", DateFormat.format("dd/MM/yy hh:mm:aa", calendar));

                nametv.setText(nm);
                phonetv.setText(phone);
                emailtv.setText(em);
                addedtv.setText(ta);
                updatedtv.setText(tu);

            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (img == null || img.isEmpty() || img.equals("null")) {
                imageView.setImageResource(R.drawable.baseline_person_24);
            } }
        cursor.close();
    }
}
