package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    private FloatingActionButton fab;
    private RecyclerView contactrv;
    DBHelper dbHelper;
    Adaptercontact adaptercontact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);

        fab = findViewById(R.id.fab);
        contactrv = findViewById(R.id.contactrv);
        contactrv.setHasFixedSize(true);
        contactrv.setLayoutManager(new LinearLayoutManager(this));

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Addeditcontact.class);
                startActivity(i);
            }
        });

        loaddata();
    }

    private void loaddata() {
        adaptercontact = new Adaptercontact(this, dbHelper.getcontacts());
        contactrv.setAdapter(adaptercontact);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        loaddata();
    }
}
