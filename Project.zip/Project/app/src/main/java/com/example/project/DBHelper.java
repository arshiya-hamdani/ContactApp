package com.example.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "contacts_db";
    public static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "contactdata";
    public static final String C_ID = "id";
    public static final String C_IMG = "Image";
    public static final String C_NAME = "name";
    public static final String C_PHONE = "phone";
    public static final String C_EMAIL = "email";
    public static final String C_ADDED_TIME = "added";
    public static final String C_UPDATED_TIME = "updated";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
                + C_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + C_NAME + " TEXT,"
                + C_PHONE + " TEXT,"
                + C_EMAIL + " TEXT,"
                + C_IMG + " TEXT," // Include 'Image' column here
                + C_ADDED_TIME + " TEXT DEFAULT CURRENT_TIMESTAMP,"
                + C_UPDATED_TIME + " TEXT DEFAULT CURRENT_TIMESTAMP"
                + ")";

        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public long insertData(String name, String phone, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(C_NAME, name);
        values.put(C_PHONE, phone);
        values.put(C_EMAIL, email);
        return db.insert(TABLE_NAME, null, values);
    }

    public ArrayList<modelclass> getcontacts() {
        ArrayList<modelclass> arrayList = new ArrayList<>();
        String selectqry = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(selectqry, null);
        while (cursor.moveToNext()) {
            modelclass mc = new modelclass();
            mc.setId(cursor.getString(cursor.getColumnIndexOrThrow(C_ID)));
            mc.setName(cursor.getString(cursor.getColumnIndexOrThrow(C_NAME)));
            mc.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(C_EMAIL)));
            mc.setImage(cursor.getString(cursor.getColumnIndexOrThrow(C_IMG)));
            mc.setAddedtime(cursor.getString(cursor.getColumnIndexOrThrow(C_ADDED_TIME)));
            mc.setUpdatedtime(cursor.getString(cursor.getColumnIndexOrThrow(C_UPDATED_TIME)));
            arrayList.add(mc);
        }
        cursor.close();
        return arrayList;
    }
}
