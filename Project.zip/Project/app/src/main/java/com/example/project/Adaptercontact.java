package com.example.project;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class Adaptercontact extends RecyclerView.Adapter<Adaptercontact.contactviewholder> {
    private Context context;
    private ArrayList<modelclass> contactlist;

    public Adaptercontact(Context context, ArrayList<modelclass> contactlist) {
        this.context = context;
        this.contactlist = contactlist;
    }

    @NonNull
    @Override
    public contactviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_contact, parent, false);
        return new contactviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull contactviewholder holder, int position) {
        modelclass mc = contactlist.get(position);
        String id=mc.getId();
        String name = mc.getName();
        String image = mc.getImage();

        // Set contact name
        holder.contactname.setText(name);

        // Set contact image
        if (image != null && !image.isEmpty()) {
          } else {
            holder.contactimg.setImageResource(R.drawable.baseline_person_24);
        }

        holder.contactdial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context, contactdetails.class);
                intent.putExtra("contactId",id);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return contactlist.size();
    }

    class contactviewholder extends RecyclerView.ViewHolder {
        ImageView contactimg, contactdial;
        TextView contactname;

        public contactviewholder(@NonNull View itemView) {
            super(itemView);
            contactimg = itemView.findViewById(R.id.contactimg);
            contactdial = itemView.findViewById(R.id.numberdial);
            contactname = itemView.findViewById(R.id.contact_name);
        }
    }
}
